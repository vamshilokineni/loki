from django.contrib import admin
from books_fbv.models import Book

admin.site.register(Book)