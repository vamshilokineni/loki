from django.apps import AppConfig
  

class BooksFbvConfig(AppConfig):
    name = 'books_fbv'
